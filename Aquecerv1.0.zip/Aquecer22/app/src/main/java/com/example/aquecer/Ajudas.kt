package com.example.aquecer

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Ajudas : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_ajudas)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val userId = intent.getStringExtra("userId")
        val btnPrevencao = findViewById<Button>(R.id.btn_Prevencao)
        val btnProtocolo = findViewById<Button>(R.id.btn_Protocolo)
        val btnDefensase = findViewById<Button>(R.id.btn_Defendase)
        val btnContacto = findViewById<Button>(R.id.btn_Contacto)

        val voltarImageView = findViewById<ImageView>(R.id.voltar)
        voltarImageView.setOnClickListener {
            // Cria um Intent para ir para a classe ViewPrincipal
            val intent = Intent(this, ViewPrincipal::class.java)
            intent.putExtra("userId", userId)
            startActivity(intent)
        }

        btnPrevencao.setOnClickListener {
            val intent = Intent(this, Prevencao::class.java)
            intent.putExtra("userId", userId)
            startActivity(intent)
        }

        btnProtocolo.setOnClickListener {
            val intent = Intent(this, Protocolo::class.java)
            intent.putExtra("userId", userId)
            startActivity(intent)
        }

        btnDefensase.setOnClickListener {
            val intent = Intent(this, Defendase::class.java)
            intent.putExtra("userId", userId)
            startActivity(intent)
        }

        btnContacto.setOnClickListener {
            val intent = Intent(this, Contacto::class.java)
            intent.putExtra("userId", userId)
            startActivity(intent)
        }


    }
    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        // Não chama super.onBackPressed() para desabilitar o botão de voltar
    }
}