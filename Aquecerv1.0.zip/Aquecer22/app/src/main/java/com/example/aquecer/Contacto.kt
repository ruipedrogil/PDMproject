package com.example.aquecer

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

class Contacto : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val userId = intent.getStringExtra("userId") ?: ""

        setContentView(R.layout.activity_contacto)

        findViewById<Button>(R.id.btn_112).setOnClickListener {
            dialNumber("112")
        }
        findViewById<Button>(R.id.btn_bombeiros).setOnClickListener {
            dialNumber("80962000")
        }
        findViewById<Button>(R.id.btn_policia).setOnClickListener {
            dialNumber("218111000")
        }
        findViewById<Button>(R.id.btn_gnr).setOnClickListener {
            dialNumber("213219000")
        }

        val voltarImageView = findViewById<ImageView>(R.id.voltar)
        voltarImageView.setOnClickListener {
            val intent = Intent(this, Ajudas::class.java)
            intent.putExtra("userId", userId)
            startActivity(intent)
        }

    }

    private fun dialNumber(number: String) {
        val intent = Intent(Intent.ACTION_DIAL).apply {
            data = Uri.parse("tel:$number")
        }
        startActivity(intent)
    }

    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        // Não chama super.onBackPressed() para desabilitar o botão de voltar
    }
}
