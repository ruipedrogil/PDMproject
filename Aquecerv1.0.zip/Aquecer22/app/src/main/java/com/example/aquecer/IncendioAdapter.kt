package com.example.aquecer


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class IncendioAdapter(
    private val incendios: List<Incendio>,
    private val onClickDetalhes: (String) -> Unit,
    private val onClickRemover: (String) -> Unit
) : RecyclerView.Adapter<IncendioAdapter.IncendioViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): IncendioViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_incendio, parent, false)
        return IncendioViewHolder(view)
    }

    override fun onBindViewHolder(holder: IncendioViewHolder, position: Int) {
        val incendio = incendios[position]
        holder.bind(incendio, onClickDetalhes, onClickRemover)
    }

    override fun getItemCount(): Int = incendios.size

    class IncendioViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvLocal: TextView = itemView.findViewById(R.id.tvLocal)
        private val tvReports: TextView = itemView.findViewById(R.id.tvReports)
        private val tvNivelPerigo: TextView = itemView.findViewById(R.id.tvNivelPerigo)
        private val tvVerificado: TextView = itemView.findViewById(R.id.tvVerificado)

        fun bind(
            incendio: Incendio,
            onClickDetalhes: (String) -> Unit,
            onClickRemover: (String) -> Unit
        ) {
            tvLocal.text = incendio.local
            tvReports.text = incendio.quantidade.toString()
            tvNivelPerigo.text = incendio.nivelPerigo.toString()
            tvVerificado.text = if (incendio.verificado) "Sim" else "Não"

            itemView.setOnClickListener { onClickDetalhes(incendio.id) }
            itemView.setOnLongClickListener {
                onClickRemover(incendio.id)
                true
            }
            }
        }


}