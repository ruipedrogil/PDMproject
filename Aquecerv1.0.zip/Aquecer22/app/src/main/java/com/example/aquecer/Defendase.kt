package com.example.aquecer

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Defendase : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val userId = intent.getStringExtra("userId") ?: ""
        setContentView(R.layout.activity_defendase)
        val voltarImageView = findViewById<ImageView>(R.id.voltar)
        voltarImageView.setOnClickListener {
            val intent = Intent(this, Ajudas::class.java)
            intent.putExtra("userId", userId)
            startActivity(intent)
        }

    }
    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        // Não chama super.onBackPressed() para desabilitar o botão de voltar
    }

}