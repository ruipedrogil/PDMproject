package com.example.aquecer

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ViewPrincipal : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_principal)

        val userId = intent.getStringExtra("userId")

        // Referência aos botões
        val btnHeatmap = findViewById<Button>(R.id.btn_heatmap)
        val btnReportedFires = findViewById<Button>(R.id.btn_reported_fires)
        val btnEducateYourself = findViewById<Button>(R.id.btn_educate_yourself)
        val btnReportFire = findViewById<Button>(R.id.btn_report_fire)
        val txtFrase = findViewById<TextView>(R.id.frase)
        val logOut = findViewById<ImageView>(R.id.voltar)
        txtFrase.text = Frases().sortearFrase()

        logOut.setOnClickListener(){
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        // Configurar ações para os botões
        btnHeatmap.setOnClickListener {
            // Exemplo: Abrir uma nova Activity ou exibir um mapa de calor
            val intent = Intent(this, HeatmapActivity::class.java)
            intent.putExtra("userId", userId)
            startActivity(intent)
        }

        btnReportedFires.setOnClickListener {
            // Exemplo: Navegar para a tela de incêndios reportados
            val intent = Intent(this, IncendiosReportados::class.java)
            intent.putExtra("userId", userId)
            startActivity(intent)
        }

        btnEducateYourself.setOnClickListener {
            // Exemplo: Navegar para uma página de informações educativas
            val intent = Intent(this, Ajudas::class.java)
            intent.putExtra("userId", userId)
            startActivity(intent)
        }

        btnReportFire.setOnClickListener {
            // Exemplo: Navegar para um formulário para reportar incêndios
            val intent = Intent(this, Report::class.java)
            intent.putExtra("userId", userId)
            startActivity(intent)
        }
    }

    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        // Não chama super.onBackPressed() para desabilitar o botão de voltar
    }
}
