package com.example.aquecer

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.database.*

class RegistoActivity : AppCompatActivity()  {
    private lateinit var firebaseAnalytics: FirebaseAnalytics
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.registo_activity)
        val button = findViewById<Button>(R.id.registo)
        val emailEditText = findViewById<EditText>(R.id.email)
        val passwordEditText = findViewById<EditText>(R.id.password)
        val passConfirmedText = findViewById<EditText>(R.id.confirm_pass)
        val nomeEditText = findViewById<EditText>(R.id.nome)
        val irLogin = findViewById<TextView>(R.id.jaTemConta)
        firebaseAnalytics = FirebaseAnalytics.getInstance(this)

        // Initialize Firebase Database
        database = FirebaseDatabase.getInstance().reference

        irLogin.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        button.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()
            val passconf = passConfirmedText.text.toString()
            val nome = nomeEditText.text.toString()

            if (email.isEmpty() || password.isEmpty() || nome.isEmpty() || passconf.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!isValidEmail(email)) {
                Toast.makeText(this, "Email inválido", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (!isValidName(nome)) {
                Toast.makeText(this, "Nome inválido", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (password.length < 6) {
                Toast.makeText(this, "A senha deve ter pelo menos 6 caracteres", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (password != passconf) {
                Toast.makeText(this, "Passwords não coincidem", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Check if email already exists
            checkIfEmailExists(email) { exists ->
                if (exists) {
                    Toast.makeText(this, "Email já registado", Toast.LENGTH_SHORT).show()
                } else {
                    val userId = database.push().key
                    if (userId == null) {
                        Toast.makeText(this, "Failed to generate user ID", Toast.LENGTH_SHORT).show()
                        return@checkIfEmailExists
                    }

                    // Create a new user object
                    val user = User(userId, nome, email, password, admin=false)

                    // Save the user to the database
                    database.child("users").child(userId).setValue(user)
                        .addOnSuccessListener {
                            Toast.makeText(this, "User guardado com sucesso", Toast.LENGTH_SHORT).show()
                            // Create an Intent to start ViewPrincipal activity
                            val intent = Intent(this, MainActivity::class.java)
                            intent.putExtra("userId", userId)
                            intent.putExtra("email", email)
                            startActivity(intent)
                        }
                        .addOnFailureListener { e ->
                            Log.e("RegistoActivity", "Failed to save user: ${e.message}", e)
                            Toast.makeText(this, "Failed to save user: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                }
            }
        }
    }

    private fun isValidEmail(email: String): Boolean {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    private fun isValidName(name: String): Boolean {
        return name.matches(Regex("^[A-Za-zÀ-ÖØ-öø-ÿ\\s]+$"))
    }

    private fun checkIfEmailExists(email: String, callback: (Boolean) -> Unit) {
        val userRef = database.child("users").orderByChild("email").equalTo(email)
        userRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                callback(dataSnapshot.exists())
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Log.e("RegistoActivity", "Database error: ${databaseError.message}", databaseError.toException())
                callback(false)
            }
        })
    }

    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        // Não chama super.onBackPressed() para desabilitar o botão de voltar
    }
}