package com.example.aquecer

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.widget.ImageView
import android.widget.Spinner
import android.widget.Toast
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener

class Report : AppCompatActivity() {

    private var lat: Double = 0.0
    private var long: Double = 0.0
    private lateinit var tipoInc: EditText
    private lateinit var detalhe: EditText
    private lateinit var localiButton: Button
    private lateinit var reportButton: Button
    private lateinit var firebaseAnalytics: FirebaseAnalytics
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_report)

        firebaseAnalytics = FirebaseAnalytics.getInstance(this)
        val userId = intent.getStringExtra("userId") ?: ""

        // Initialize Firebase Database
        database = FirebaseDatabase.getInstance().reference
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val voltarImageView = findViewById<ImageView>(R.id.voltar)
        voltarImageView.setOnClickListener {
            val intent = Intent(this, ViewPrincipal::class.java)
            intent.putExtra("userId", userId)
            startActivity(intent)
        }

        tipoInc = findViewById(R.id.tipos_incendios)
        detalhe = findViewById(R.id.detName)
        localiButton = findViewById(R.id.loc_name)
        reportButton = findViewById(R.id.button)

        localiButton.setOnClickListener {
            val intent = Intent(this, MarcarActivity::class.java)
            intent.putExtra("userId", userId)
            intent.putExtra("tipoInc", tipoInc.text.toString())
            intent.putExtra("detalhe", detalhe.text.toString())
            startActivityForResult(intent, 1)
        }

        reportButton.setOnClickListener {
            val tipoIncText = tipoInc.text.toString().trim()
            val detalhesText = detalhe.text.toString().trim()

            if (tipoIncText.isEmpty() || detalhesText.isEmpty()) {
                Toast.makeText(this, "Todos os campos devem ser preenchidos", Toast.LENGTH_SHORT).show()
            } else if (lat == 0.0 && long == 0.0) {
                Toast.makeText(this, "Por favor, adicione a localização do incêndio no mapa", Toast.LENGTH_SHORT).show()
            } else {
                val verified = false
                val spinner: Spinner = findViewById(R.id.spinnerNivelPerigo)
                val gravi = Integer.parseInt(spinner.getSelectedItem().toString())
                val quantidade = 1
                val data = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())

                // Verificar proximidade com incêndios existentes
                database.child("incendios").addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        var incendioProximo: Incendio? = null

                        for (dataSnapshot in snapshot.children) {
                            val incendio = dataSnapshot.getValue(Incendio::class.java)
                            if (incendio != null) {
                                val distancia = calcularDistancia(lat, long, incendio.lat, incendio.long)
                                if (distancia <= 3) { // Limite de 3000 metros
                                    incendioProximo = incendio
                                    break
                                }
                            }
                        }

                        if (incendioProximo != null) {
                            // Incrementar a quantidade no incêndio existente
                            val novaQuantidade = incendioProximo.quantidade + 1
                            var novaGravi = gravi
                            novaGravi = (incendioProximo.nivelPerigo + novaGravi) / 2
                            database.child("incendios").child(incendioProximo.id)
                                .child("quantidade").setValue(novaQuantidade)
                            database.child("incendios").child(incendioProximo.id)
                                .child("nivelPerigo").setValue(novaGravi)
                                .addOnSuccessListener {
                                    Toast.makeText(this@Report, "Incêndio reportado com sucesso", Toast.LENGTH_SHORT).show()
                                    val intent = Intent(this@Report, ViewPrincipal::class.java)
                                    intent.putExtra("userId", userId)
                                    startActivity(intent)
                                }
                                .addOnFailureListener { e ->
                                    Toast.makeText(this@Report, "Erro ao reportar incêndio: ${e.message}", Toast.LENGTH_SHORT).show()
                                }
                        } else {
                            // Criar um novo incêndio
                            val incendioId = database.push().key ?: return
                            val incendio = Incendio(
                                id = incendioId,
                                local = detalhesText,
                                verificado = verified,
                                nivelPerigo = gravi,
                                data = data,
                                userId = userId,
                                lat = lat,
                                long = long,
                                quantidade = quantidade
                            )

                            database.child("incendios").child(incendioId).setValue(incendio)
                                .addOnSuccessListener {
                                    Toast.makeText(this@Report, "Incêndio reportado com sucesso", Toast.LENGTH_SHORT).show()
                                    val intent = Intent(this@Report, ViewPrincipal::class.java)
                                    intent.putExtra("userId", userId)
                                    startActivity(intent)
                                }
                                .addOnFailureListener { e ->
                                    Toast.makeText(this@Report, "Falha ao reportar incêndio: ${e.message}", Toast.LENGTH_SHORT).show()
                                }
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        Toast.makeText(this@Report, "Erro ao acessar base de dados: ${error.message}", Toast.LENGTH_SHORT).show()
                    }
                })
            }
        }

        configurarSpinnerNivelPerigo()

        if (savedInstanceState != null) {
            tipoInc.setText(savedInstanceState.getString("tipoInc"))
            detalhe.setText(savedInstanceState.getString("detalhe"))
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("tipoInc", tipoInc.text.toString())
        outState.putString("detalhe", detalhe.text.toString())
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1 && resultCode == RESULT_OK) {
            tipoInc.setText(data?.getStringExtra("tipoInc"))
            detalhe.setText(data?.getStringExtra("detalhe"))
            lat = data?.getDoubleExtra("latitude", 0.0) ?: 0.0
            long = data?.getDoubleExtra("longitude", 0.0) ?: 0.0
        }
    }

    private fun configurarSpinnerNivelPerigo() {
        val spinner: Spinner = findViewById(R.id.spinnerNivelPerigo)
        val niveis = listOf("1", "2", "3", "4", "5")

        // Configura o adaptador com o layout customizado
        val adapter = ArrayAdapter(this, R.layout.spinner_item, niveis).apply {
            setDropDownViewResource(R.layout.spinner_dropdown_item)
        }
        spinner.adapter = adapter

        // Listener para capturar o item selecionado
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                val nivelEscolhido = parent.getItemAtPosition(position).toString()
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Caso nenhum item seja selecionado
            }
        }
    }

    private fun calcularDistancia(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val R = 6371.0 // Raio da Terra em quilômetros
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        val distancia = R * c // Distância em quilômetros
        return distancia
        }

    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        // Não chama super.onBackPressed() para desabilitar o botão de voltar
    }
}