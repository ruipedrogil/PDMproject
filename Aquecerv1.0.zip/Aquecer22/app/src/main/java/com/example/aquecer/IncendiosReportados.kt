package com.example.aquecer

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*

class IncendiosReportados : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: IncendioAdapter
    private var incendios: MutableList<Incendio> = mutableListOf()
    private lateinit var database: DatabaseReference
    private var isAdmin = false


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_incendios_reportados)

        // Initialize Firebase Database
        database = FirebaseDatabase.getInstance().reference

        val userId = intent.getStringExtra("userId")
        checkIfUserIsAdmin(userId) { isAdmin ->
            this.isAdmin = isAdmin

            val voltarImageView = findViewById<ImageView>(R.id.voltar)
            voltarImageView.setOnClickListener {
                val intent = Intent(this, ViewPrincipal::class.java)
                intent.putExtra("userId", userId)
                startActivity(intent)
            }

            recyclerView = findViewById(R.id.recyclerViewIncendios)
            recyclerView.layoutManager = LinearLayoutManager(this)
            adapter = IncendioAdapter(incendios, { id ->
                val incendio = incendios.find { it.id == id }
                if (incendio?.verificado == true && isAdmin) {
                    Toast.makeText(this@IncendiosReportados, "Este incêndio já foi verificado", Toast.LENGTH_SHORT).show()
                } else {
                    if (isAdmin) {
                        showConfirmationDialogVerif(id)
                    }
                }
            }, { id ->
                if (isAdmin) {
                    showConfirmationDialog(id)
                }
            })
            recyclerView.adapter = adapter

            // Fetch data from Firebase
            fetchIncendiosFromDatabase()
        }
    }

    private fun fetchIncendiosFromDatabase() {
        database.child("incendios").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                incendios.clear()
                for (dataSnapshot in snapshot.children) {
                    val incendio = dataSnapshot.getValue(Incendio::class.java)
                    if (incendio != null) {
                        incendios.add(incendio)
                    }
                }
                incendios.sortByDescending { it.verificado }
                adapter.notifyDataSetChanged()
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@IncendiosReportados, "Failed to load data: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun showConfirmationDialog(id: String) {
        AlertDialog.Builder(this)
            .setTitle("Confirm Deletion")
            .setMessage("Tem a certeza que quer eliminar este incendio?")
            .setPositiveButton("Yes") { dialog, _ ->
                removeIncendio(id)
                dialog.dismiss()
            }
            .setNegativeButton("No") { dialog, _ ->
                dialog.dismiss()
            }
            .create()
            .show()
    }

    private fun showConfirmationDialogVerif(id: String) {
        AlertDialog.Builder(this)
            .setTitle("Confirm Verification")
            .setMessage("Tem a certeza que quer verificar este incendio?")
            .setPositiveButton("Yes") { dialog, _ ->
                verifyIncendio(id)
                dialog.dismiss()
            }
            .setNegativeButton("No") { dialog, _ ->
                dialog.dismiss()
            }
            .create()
            .show()
    }


    private fun verifyIncendio(id: String) {
        database.child("incendios").child(id).child("verificado").setValue(true)
            .addOnSuccessListener {
                Toast.makeText(this, "Incêndio verificado com sucesso", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Falha ao verificar incêndio: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun removeIncendio(id: String) {
        database.child("incendios").child(id).removeValue()
    }

    private fun checkIfUserIsAdmin(userId: String?, callback: (Boolean) -> Unit) {
        if (userId == null) {
            callback(false)
            return
        }
        database.child("users").child(userId).child("admin")
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                    val isAdmin = dataSnapshot.getValue(Boolean::class.java) ?: false
                    callback(isAdmin)
                }
                override fun onCancelled(databaseError: DatabaseError) {
                    Log.e(
                        "IncendiosReportados",
                        "Database error: ${databaseError.message}",
                        databaseError.toException()
                    )
                    Toast.makeText(this@IncendiosReportados, "Failed to check admin status", Toast.LENGTH_SHORT).show()
                    callback(false)
                }
            })
    }
    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        // Não chama super.onBackPressed() para desabilitar o botão de voltar
    }
}