package com.example.aquecer

import kotlin.random.Random

class Frases {

    private val frases: List<String> = """
        Limpe as áreas de vegetação seca ao redor de sua casa; a prevenção começa na sua propriedade.;
        Evite queimadas, especialmente em dias de calor intenso ou vento; siga as normas de segurança.;
        Não deite cigarros ou fósforos ao chão; um pequeno descuido pode causar uma grande tragédia.;
        Informe-se sobre o índice de risco de incêndio na sua região antes de realizar atividades ao ar livre.;
        Nunca acenda fogueiras ou grelhadores em áreas florestais, especialmente durante o verão.;
        Respeite os avisos e proibições de acesso às florestas em períodos de risco elevado de incêndio.;
        Tenha sempre um plano de evacuação preparado e siga as instruções das autoridades.;
        Não abandone lixo nas florestas; vidros e outros materiais podem refletir o sol e causar incêndios.;
        Se avistar um incêndio, ligue de imediato para o 112 e informe a localização.;
        Participe em iniciativas locais de limpeza e sensibilização para proteger as florestas da sua comunidade.;
        Crie uma faixa de proteção de 50 metros ao redor da sua casa, mantendo a vegetação sob controlo.;
        Nunca armazene materiais inflamáveis perto de habitações ou áreas florestais.;
        Ao usar máquinas agrícolas ou ferramentas no campo, evite trabalhar nas horas de maior calor.;
        Certifique-se de que as chaminés estão limpas e de que as cinzas são descartadas em locais seguros.;
        Se vive perto de florestas, mantenha mangueiras, baldes de água ou extintores sempre acessíveis.;
        Plante espécies menos inflamáveis ao redor da sua casa; árvores como sobreiros e carvalhos são boas opções.;
        Participe em ações de formação e esteja preparado para agir em caso de emergência.;
        Eduque as crianças sobre os perigos do fogo e a importância da proteção ambiental.;
        Respeite o período crítico de incêndios, geralmente entre julho e setembro, e adote medidas adicionais de precaução.;
        Denuncie atividades suspeitas ou comportamentos imprudentes que possam causar incêndios.;
        Verifique regularmente as instalações elétricas para evitar curtos-circuitos.;
        Nunca deixe velas acesas sem supervisão.;
        Instale detectores de fumo e revise-os periodicamente.;
        Tenha um extintor de incêndio em casa e saiba como usá-lo.;
        Não sobrecarregue tomadas com múltiplos equipamentos ligados.;
        Armazene líquidos inflamáveis em locais ventilados e longe do calor.;
        Não deixe panelas ou frigideiras no fogão sem vigilância.;
        Certifique-se de apagar completamente qualquer fonte de fogo em lareiras ou churrasqueiras.;
        Desligue aparelhos elétricos que não estão a ser usados, especialmente em dias quentes.;
        Garanta que as saídas de emergência na sua casa estão desimpedidas.;
        Respeite a proibição de acender fogos em áreas protegidas.;
        Leve sempre sacos para recolher o lixo nas florestas.;
        Evite cortar ou queimar mato durante os períodos de maior risco de incêndio.;
        Cuidado com faíscas ao usar motosserras ou outras máquinas perto de vegetação seca.;
        Nunca deixe fogueiras acesas ao sair de um acampamento.;
        Certifique-se de que os seus animais de estimação não desloquem materiais inflamáveis.;
        Reforce o cuidado com linhas elétricas que passam por áreas de vegetação.;
        Evite estacionar carros em cima de vegetação seca; os escapes podem causar incêndios.;
        Não pratique atividades com drones que possam sobrevoar áreas com risco de faíscas.;
        Se vir lixo acumulado numa floresta, reporte às autoridades locais.;
        Trate o fogo com respeito: ele é útil, mas também perigoso.;
        Informe os seus vizinhos sobre boas práticas de prevenção de incêndios.;
        Participe em simulacros organizados pela Proteção Civil.;
        Tenha sempre à mão os contactos de emergência locais.;
        Nunca brinque com fósforos ou isqueiros, especialmente perto de crianças.;
        Use fogões a gás em locais bem ventilados para evitar explosões acidentais.;
        Seja prudente ao organizar festas com churrascos ao ar livre.;
        Desconfie de comportamentos negligentes nas áreas rurais e comunique às autoridades.;
        Promova a limpeza de terrenos junto à sua comunidade.;
        Não ignore pequenos focos de fumo; a sua rápida reação pode salvar vidas.;
        Evite usar fogo ou ferramentas de aquecimento ao ar livre em dias de risco elevado.;
        Informe-se sobre os alertas meteorológicos e respeite-os.;
        Evite deitar cinzas quentes em contentores ou terrenos, mesmo que pareçam apagadas.;
        Seja vigilante: uma pequena faísca pode ser o início de um grande incêndio.;
        Evite usar produtos pirotécnicos em zonas de vegetação seca.;
        Se notar vegetação densa e descontrolada perto de sua casa, contacte as autoridades competentes.;
        Colabore com os bombeiros locais em campanhas de sensibilização sobre incêndios.;
        Nunca deixe crianças a brincar perto de fontes de calor ou fogo.;
        Verifique se as grelhas de segurança das lareiras estão devidamente instaladas.;
        Coloque cercas ou barreiras naturais para criar zonas corta-fogo ao redor da sua propriedade.;
        Evite construir casas com materiais inflamáveis em zonas rurais.;
        Mantenha depósitos de água em locais estratégicos para combate rápido a incêndios.;
        Certifique-se de que todas as saídas de emergência estão desbloqueadas e sinalizadas.;
        Comunique com os seus vizinhos para criar um plano comunitário de prevenção de incêndios.;
        Se trabalha no campo, use sapatos antiestáticos para evitar descargas elétricas.;
        Evite armazenar pneus velhos perto de vegetação, pois são altamente inflamáveis.;
        Participe em voluntariado para vigilância em áreas florestais durante o verão.;
        Reforce as janelas e portas da sua casa com materiais resistentes ao fogo.;
        Evite usar lanternas a gás em áreas florestais sem supervisão.;
        Comunique às autoridades árvores em risco de queda sobre linhas elétricas.;
        Limite o uso de fertilizantes químicos inflamáveis em zonas agrícolas.;
        Ajude a criar pontos de água acessíveis para os bombeiros na sua área.;
        Aplique tratamentos anti-chamas em superfícies de madeira no exterior da sua casa.;
        Tenha um kit de emergência preparado com água, máscaras e primeiros socorros.;
        Utilize equipamento agrícola com dispositivos de prevenção de faíscas.;
        Se acampar, certifique-se de que não há folhas secas perto da fogueira.;
        Faça manutenção periódica aos extintores de incêndio da sua casa ou empresa.;
        Seque roupas ao sol e não em aquecedores elétricos para evitar sobrecarga térmica.;
        Nunca abandone garrafas de vidro na floresta; podem causar focos de incêndio.;
        Evite o uso de sprays aerossóis perto de chamas ou calor excessivo.;
        Se viver numa zona de risco, tenha um alarme conectado diretamente aos bombeiros.;
        Informe-se sobre as regras locais de prevenção de incêndios antes de usar espaços públicos.;
        Monitore regularmente as condições de segurança dos terrenos florestais vizinhos.;
        Apoie iniciativas de reflorestação para evitar erosões e melhorar o controlo de fogos.;
        Se usar velas, mantenha-as afastadas de tecidos ou cortinas.;
        Consulte os bombeiros locais para dicas sobre proteção de propriedades rurais.;
        Evite construir fogueiras em locais com vento forte.;
        Tenha ferramentas de combate a incêndios, como pás ou ancinhos, sempre à mão.;
        Inscreva-se em workshops de segurança contra incêndios organizados pela comunidade.;
        Ajude a remover árvores mortas que possam servir de combustível para incêndios.;
        Mantenha os seus animais afastados de fontes de fogo ou calor intenso.;
        Seja prudente ao realizar festas com fogos de artifício, especialmente em áreas rurais.;
        Evite estacionar máquinas agrícolas em áreas com vegetação seca durante o verão.;
        Recolha folhas secas e outros materiais inflamáveis acumulados no seu quintal.;
        Certifique-se de que as suas calhas estão limpas e livres de detritos inflamáveis.;
        Coloque sinalizações em trilhos florestais alertando para os perigos do fogo.;
        Se notar fumaça em locais remotos, informe de imediato as autoridades.;
        Planeie rotas de evacuação e pratique-as com os membros da sua família.;
        Invista em bombas de água portáteis para emergências em zonas rurais.;
        Incentive o uso de drones por autoridades para monitorizar áreas florestais.;
        Ensine os seus filhos sobre a importância de proteger as florestas e a natureza;
    """.trimIndent().split(";")

    fun sortearFrase(): String {
        return frases[Random.nextInt(frases.size)]
    }
}