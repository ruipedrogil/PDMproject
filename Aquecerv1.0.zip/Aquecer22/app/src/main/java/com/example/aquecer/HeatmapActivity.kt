package com.example.aquecer

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.os.Bundle
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.firebase.database.*
import java.util.Locale

class HeatmapActivity : AppCompatActivity(), OnMapReadyCallback, GoogleMap.OnMarkerClickListener {

    private lateinit var map: GoogleMap
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var database: DatabaseReference
    private val LOCATION_PERMISSION_REQUEST_CODE = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_heatmap)

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map_fragment) as SupportMapFragment
        mapFragment.getMapAsync(this)

        val userId = intent.getStringExtra("userId")

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        database = FirebaseDatabase.getInstance().reference.child("incendios")

        val voltarImageView = findViewById<ImageView>(R.id.voltar)
        voltarImageView.setOnClickListener {
            val intent = Intent(this, ViewPrincipal::class.java)
            intent.putExtra("userId", userId)
            startActivity(intent)
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        map.uiSettings.isZoomControlsEnabled = true
        map.setOnMarkerClickListener(this)
        setUpMap()
        fetchVerifiedIncendios()
    }

    override fun onMarkerClick(marker: Marker): Boolean {
        return false
    }

    private fun setUpMap() {
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                LOCATION_PERMISSION_REQUEST_CODE
            )
            return
        }
        map.isMyLocationEnabled = true
        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                val currentLatLng = LatLng(location.latitude, location.longitude)
                map.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 12f))
            } else {
                val defaultLocation = LatLng(-23.5505, -46.6333)
                map.animateCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, 12f))
            }
        }.addOnFailureListener { e ->
            e.printStackTrace()
        }
    }

    private fun fetchVerifiedIncendios() {
        val currentDate = java.util.Calendar.getInstance().time
        val twoWeeksAgo = java.util.Calendar.getInstance().apply {
            add(java.util.Calendar.DAY_OF_YEAR, -14)
        }.time

        database.orderByChild("verificado").equalTo(true).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                for (dataSnapshot in snapshot.children) {
                    val incendio = dataSnapshot.getValue(Incendio::class.java)
                    if (incendio != null) {
                        val incendioDate = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).parse(incendio.data)
                        if (incendioDate != null && incendioDate.after(twoWeeksAgo) && incendioDate.before(currentDate)) {
                            val location = LatLng(incendio.lat, incendio.long)
                            val geocoder = Geocoder(this@HeatmapActivity, Locale.getDefault())
                            val addresses = geocoder.getFromLocation(incendio.lat, incendio.long, 1)
                            val address = if (!addresses.isNullOrEmpty()) addresses[0].locality else "Unknown Location"
                            map.addMarker(MarkerOptions().position(location).title(address))
                        }
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@HeatmapActivity, "Failed to load data: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                setUpMap()
            }
           }
        }

    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        // Não chama super.onBackPressed() para desabilitar o botão de voltar
    }
}