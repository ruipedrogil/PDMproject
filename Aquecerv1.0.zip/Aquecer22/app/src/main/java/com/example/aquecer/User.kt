package com.example.aquecer

data class User(val userId: String,
                val nome: String,
                val email: String,
                val password: String,
                var admin: Boolean)