package com.example.aquecer

data class Incendio(
    val id: String = "",
    val local: String = "",
    val verificado: Boolean = false,
    val nivelPerigo: Int = 0,
    val data: String = "",
    val userId: String = "",
    val lat: Double = 0.0,
    val long: Double = 0.0,
    val quantidade: Int = 0
) {
    // No-argument constructor for Firebase
    constructor() : this("", "", false, 0, "", "", 0.0, 0.0, 0)
}
