package com.example.aquecer

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.analytics.FirebaseAnalytics
import com.google.firebase.database.*

class MainActivity : AppCompatActivity() {
    private lateinit var firebaseAnalytics: FirebaseAnalytics
    private lateinit var database: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize Firebase Analytics
        firebaseAnalytics = FirebaseAnalytics.getInstance(this)

        // Initialize Firebase Database
        database = FirebaseDatabase.getInstance().reference

        val emailEditText = findViewById<EditText>(R.id.email)
        val passwordEditText = findViewById<EditText>(R.id.pass)
        val loginButton = findViewById<Button>(R.id.button)
        val irRegisto = findViewById<TextView>(R.id.naoTemConta)

        irRegisto.setOnClickListener() {
            val intent = Intent(this, RegistoActivity::class.java)
            startActivity(intent)
        }

        loginButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()

            // Verify login credentials
            verifyLogin(email, password)
        }
    }

    private fun verifyLogin(email: String, password: String) {
        val userRef = database.child("users").orderByChild("email").equalTo(email)
        userRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                if (dataSnapshot.exists()) {
                    for (userSnapshot in dataSnapshot.children) {
                        val dbPassword = userSnapshot.child("password").getValue(String::class.java)
                        if (dbPassword == password) {
                            // Login successful
                            val userId = userSnapshot.key
                            val intent = Intent(this@MainActivity, ViewPrincipal::class.java)
                            intent.putExtra("userId", userId)
                            startActivity(intent)
                        } else {
                            Toast.makeText(this@MainActivity, "Invalid password", Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    Toast.makeText(this@MainActivity, "Não foi possível realizar o login", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onCancelled(databaseError: DatabaseError) {
                Toast.makeText(this@MainActivity, "Database error: ${databaseError.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    @SuppressLint("MissingSuperCall")
    override fun onBackPressed() {
        // Não chama super.onBackPressed() para desabilitar o botão de voltar
    }
}